package com.cognizant.model;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class ServiceCategory {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int sCategoryId;
	private String sCategoryName;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "vendor_id")
	private Vendor vendor;

	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "customer_id")
	private Customer customer;
	
	public ServiceCategory() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sCategoryId
	 * @param sCategoryName
	 * @param vendor
	 * @param customer
	 */
	public ServiceCategory(int sCategoryId, String sCategoryName, Vendor vendor, Customer customer) {
		super();
		this.sCategoryId = sCategoryId;
		this.sCategoryName = sCategoryName;
		this.vendor = vendor;
		this.customer = customer;
	}

	public int getsCategoryId() {
		return sCategoryId;
	}

	public void setsCategoryId(int sCategoryId) {
		this.sCategoryId = sCategoryId;
	}

	public String getsCategoryName() {
		return sCategoryName;
	}

	public void setsCategoryName(String sCategoryName) {
		this.sCategoryName = sCategoryName;
	}

	public Vendor getVendor() {
		return vendor;
	}

	public void setVendor(Vendor vendor) {
		this.vendor = vendor;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}






}
