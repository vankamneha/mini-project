package com.cognizant.model;

import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;

@Entity
public class Vendor {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@NotBlank(message = "First Name should not be empty")
	private String firstName;
	@NotBlank(message = "Last Name shold not be empty")
	private String lastName;
	// @NotBlank(message = "Date of birth should not be empty")
	// private Date dob;
	@NotEmpty(message = "Gender should be specitfied")
	private String gender;
	@NotBlank(message = "Contact number should not be empty")
	@Pattern(regexp = "(^$|[0-9]{10})", message = "Contact number should be 10 digits")
	private String contactNumber;
	@NotBlank(message = "Address should not be empty")
	private String address;
	@NotBlank(message = "City should not be empty")
	private String city;
	@NotBlank(message = "State should not be empty")
	private String state;
	@NotBlank(message = "Zip code should not be empty")
	private String zip;
	@NotBlank(message = "Email should not be empty")
	private String email;
	@NotBlank(message = "Vendor Id code should not be empty")
	private String vendorUserId;
	@NotBlank(message = "Password should not be empty")
	private String password;
	private String secretQ;
	@NotBlank(message = "Secret answer should not be empty")
	private String secretAns;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "vendor")
	private List<ProductCategory> productCategory;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "vendor")
	private List<ServiceCategory> serviceCategory;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "vendor")
	private List<Product> product;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "vendor")
	private List<Service> service;

	public Vendor() {
		// TODO Auto-generated constructor stub
	}
	public Vendor(Integer id, @NotBlank(message = "First Name should not be empty") String firstName,
			@NotBlank(message = "Last Name shold not be empty") String lastName,
			@NotEmpty(message = "Gender should be specitfied") String gender,
			@NotBlank(message = "Contact number should not be empty") @Pattern(regexp = "(^$|[0-9]{10})", message = "Contact number should be 10 digits") String contactNumber,
			@NotBlank(message = "Address should not be empty") String address,
			@NotBlank(message = "City should not be empty") String city,
			@NotBlank(message = "State should not be empty") String state,
			@NotBlank(message = "Zip code should not be empty") String zip,
			@NotBlank(message = "Email should not be empty") String email,
			@NotBlank(message = "Vendor Id code should not be empty") String vendorUserId,
			@NotBlank(message = "Password should not be empty") String password, String secretQ,
			@NotBlank(message = "Secret answer should not be empty") String secretAns,
			List<ProductCategory> productCategory, List<ServiceCategory> serviceCategory, List<Product> product,
			List<Service> service) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.contactNumber = contactNumber;
		this.address = address;
		this.city = city;
		this.state = state;
		this.zip = zip;
		this.email = email;
		this.vendorUserId = vendorUserId;
		this.password = password;
		this.secretQ = secretQ;
		this.secretAns = secretAns;
		this.productCategory = productCategory;
		this.serviceCategory = serviceCategory;
		this.product = product;
		this.service = service;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getVendorUserId() {
		return vendorUserId;
	}

	public void setVendorUserId(String vendorUserId) {
		this.vendorUserId = vendorUserId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getSecretQ() {
		return secretQ;
	}

	public void setSecretQ(String secretQ) {
		this.secretQ = secretQ;
	}

	public String getSecretAns() {
		return secretAns;
	}

	public void setSecretAns(String secretAns) {
		this.secretAns = secretAns;
	}

	public List<ProductCategory> getProductCategory() {
		return productCategory;
	}

	public void setProductCategory(List<ProductCategory> productCategory) {
		this.productCategory = productCategory;
	}

	public List<ServiceCategory> getServiceCategory() {
		return serviceCategory;
	}

	public void setServiceCategory(List<ServiceCategory> serviceCategory) {
		this.serviceCategory = serviceCategory;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public List<Service> getService() {
		return service;
	}

	public void setService(List<Service> service) {
		this.service = service;
	}

}
