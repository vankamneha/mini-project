package com.cognizant.service;

import java.util.List;

public interface ProductCategoryService {
    List<String> getCategories(int vid);
}
