package com.cognizant.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.model.Product;
@Repository
public interface ProductDao extends JpaRepository<Product, Integer>{
	Product findByProductId(int pid);
	//@Query(value="select * from product where vendor_id=?1",nativeQuery = true)
	List<Product> findByVendorId(int i);

}
