package com.cognizant.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.model.ServiceCategory;
@Repository
public interface ServiceCategoryDao extends JpaRepository<ServiceCategory, Integer> {

}
