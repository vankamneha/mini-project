package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.dao.CustomerDao;
import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.model.Customer;
import com.cognizant.model.Product;
import com.cognizant.service.CustomerService;

@Controller
public class CustomerController {
	@Autowired
	private CustomerDao customerDao;

	@Autowired
	private ProductDao productDao;
	@Autowired
	private ProductCategoryDao productCategoryDao;
	
	
	
	@GetMapping("/customer")
	public String viewCustomerRegister(Model model) {
		Customer customer=new Customer();
		model.addAttribute("customer",customer);
		return "customerRegister";
	}
	@PostMapping("/customerRegister")
	public String addVendor(@Valid @ModelAttribute("customer") Customer customer,BindingResult result,ModelMap map) {
		if(result.hasErrors()) {
			return "customerRegister";
		}
		
		customerDao.save(customer);
		
		return "customerRegisterSuccess";		
	}
	
	@GetMapping("/customerLogin")
	public String customerLogin() {
		
		return "customerLogin";
	}
	@PostMapping("/customerAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password,HttpSession session,Model model,HttpServletRequest request) {
	     Customer correct=customerDao.findByCustomerUserIdAndPassword(username,password);
	     if (!(ObjectUtils.isEmpty(correct))) {
	    	session.setAttribute("username", username);
	    	System.out.println(session.getAttribute("username"));
	    	request.setAttribute("mode", "MODE_HOME");
	    	return "customer";
	     }
	     else {
	    	 System.out.println("false");
	    	   model.addAttribute("msg", "Invalid Login Credentials");
	    		return "customerLogin";
	     }
		
	}
	@GetMapping("/customerLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
//	
//	@RequestMapping("/viewProduct")
//	public String getProduct(@RequestParam(name = "id") int id,ModelMap model) {
//		List<Product> pList=productDao.findAllByProductCaregoryId(1);
//		System.out.println(pList);
//		model.addAttribute("pList",pList);
//		return "customer";
//	}
//	
	
	
	@PostMapping("/getProductByCategory/{categoryId}")
	public String getProductByCategory(@PathVariable(name = "categoryId") int categoryId,ModelMap model,HttpServletRequest request) {
		List<Product> pList=productCategoryDao.findAllByProductCategoryId(categoryId);
		if(pList!=null) {
			System.out.println(pList);
		}
		model.addAttribute("productList",pList);
		request.setAttribute("mode", "MODE_PRODUCTLIST");
		return "customer";
	}
	
	@PostMapping("/getProductDetails/{productId}")
	public String getProductDetails(@PathVariable(name = "productId") int productId,ModelMap model,HttpServletRequest request) {
		Product product=productDao.findByProductId(productId);
		model.addAttribute("product", product);
		request.setAttribute("mode", "MODE_PRODUCTDETAILS");
		return "customer";
	}
	@ModelAttribute("secretQ")
	public List<String> populateQ(){
		List<String> secretQ=new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;
	}


}
