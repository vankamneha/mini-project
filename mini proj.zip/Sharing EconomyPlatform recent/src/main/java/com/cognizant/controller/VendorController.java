package com.cognizant.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import com.cognizant.service.ProductCategoryService;
import com.cognizant.service.ProductCategoryServiceImpl;
import org.apache.coyote.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.ObjectUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.RequestDataValueProcessor;

import com.cognizant.dao.ProductCategoryDao;
import com.cognizant.dao.ProductDao;
import com.cognizant.dao.VendorDao;
import com.cognizant.model.Product;
import com.cognizant.model.ProductCategory;
import com.cognizant.model.Vendor;

@Controller
public class VendorController {
	@Autowired
	private VendorDao vendorDao;
	@Autowired
	private ProductDao productDao;
	@Autowired
	private ProductCategoryDao productCategoryDao;
	@Autowired
	private ProductCategoryService productCategoryService;
	@GetMapping("/vendor")
	public String viewVendorRegister(Model model) {
		Vendor vendor = new Vendor();
		model.addAttribute("vendor", vendor);
		return "vendorRegister";
	}

	@PostMapping("/vendorRegister")
	public String addVendor(@Valid @ModelAttribute("vendor") Vendor vendor, BindingResult result, ModelMap map) {
		if (result.hasErrors()) {
			return "vendorRegister";
		}

		vendorDao.save(vendor);
		return "vendorRegisterSuccess";
	}

	@GetMapping("/vendorLogin")
	public String vendorLogin() {

		return "vendorLogin";
	}

	@PostMapping("/vendorAuthentication")
	public String loginAuthentication(@RequestParam("username") String username,
			@RequestParam("password") String password, HttpSession session, Model model, HttpServletRequest request) {
		Vendor vendor = vendorDao.findByVendorUserIdAndPassword(username, password);
		if (!(ObjectUtils.isEmpty(vendor))) {
			session.setAttribute("username", username);
			System.out.println(session.getAttribute("username"));
			request.setAttribute("mode", "MODE_HOME");
			return "vendor";
		} else {
			System.out.println("false");
			model.addAttribute("msg", "Invalid Login Credentials");
			return "vendorLogin";
		}
	}
	@GetMapping("/vendorLogout")
	public String logout(HttpSession session) {
		System.out.println(session.getAttribute("username"));
		session.removeAttribute("username");
		System.out.println(session.getAttribute("username"));
		return "redirect:/";
	}
	@GetMapping("/categories")
	@ResponseBody  public List<String> getCategories(HttpSession session){
		String vendorUserId=(String)session.getAttribute("username");
		Vendor vendor=vendorDao.findByVendorUserId(vendorUserId);
		List<String> categories=productCategoryService.getCategories(vendor.getId());
		return  categories;
	}
	@GetMapping("/addproducts/{categoryName}")
	public String showAddProduct(@PathVariable("categoryName")  String categotyName,Model model){
		ProductCategory productCategory=productCategoryDao.findProductCategoryByProductCategoryName(categotyName);
		model.addAttribute("category",productCategory);
		return "addproducts";
	}
//	@RequestMapping("/viewProduct")
//	public String getProduct() {
//		List<Product> pList = productDao.findByVendorId(1);
//		for(Product p:pList) {
//		System.out.println(p.getPrice());
//		}
//		model.addAttribute("pList",pList);
//		return "customer";
//	}

	@RequestMapping("/addProductCategory")
	public String addProductCategory(@ModelAttribute("productCategory") ProductCategory productCategory, ModelMap map) {
		ProductCategory productCatrgory = new ProductCategory();
		productCategoryDao.save(productCategory);

		return "";

	}
	
	

	@ModelAttribute("secretQ")
	public List<String> populateQ() {
		List<String> secretQ = new ArrayList<>();
		secretQ.add("What is your childhood name");
		secretQ.add("What is your pet name");
		secretQ.add("Who is your childhood friend");
		return secretQ;

	}

}
